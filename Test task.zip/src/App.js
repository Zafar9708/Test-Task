import React from 'react';

import TableFlow from './TableFlow';



const App = () => {
  return (<>
       <TableFlow/>
     </>)
}

export default App;

